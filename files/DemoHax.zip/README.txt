Hello, thanks for downloading this client! 

DIRECTIONS:

1. drag the folder with the name of the client to the .minecraft/versions  folder.
2. open the minecraft laucher
3. click installations
4. click new and select the version dropdown menu
5. scroll down until you see the "release CLIENTNAME" e.g "release EnderHax"
6. select it and click "create"
7. scroll down to the bottom of the installations menu and click play on the client name.
8. Enjoy :)